<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Requests\CommentFormRequest;
use App\Comments;
class CommentsController extends Controller
{
public function newComment(CommentFormRequest $request)
{

$comment = new Comments(array(
'post_id' => $request->get('post_id'),
'content' => $request->get('content')
));
$comment->save();
return redirect()->back()->with('status', 'Your comment has been created');
}
}