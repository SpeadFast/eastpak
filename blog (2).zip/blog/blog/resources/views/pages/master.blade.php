<html>
<head>
<title> @yield('title') </title>
<meta name="keyword" content="html5, css, bootstrap, property, real-estate theme , bootstrap template">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="{{asset('css/normalize.css')}}">
        <link rel="stylesheet" href="{{asset('css/font-awesome.min.css')}}">
        <link rel="stylesheet" href="{{asset('css/fontello.css')}}">
        <link href="{{asset('css/fonts/icon-7-stroke/css/pe-icon-7-stroke.css')}}" rel="stylesheet">
        <link href="{{asset('css/fonts/icon-7-stroke/css/helper.css')}}" rel="stylesheet">
        <link href="{{asset('css/animate.css" rel="stylesheet')}}" media="screen">
        <link rel="stylesheet" href="{{asset('css/bootstrap-select.min.css')}}"> 
        <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
        <link rel="stylesheet" href="{{asset('css/icheck.min_all.css')}}">
        <link rel="stylesheet" href="{{asset('css/price-range.css')}}">
        <link rel="stylesheet" href="{{asset('css/owl.carousel.css')}}">  
        <link rel="stylesheet" href="{{asset('css/owl.theme.css')}}">
        <link rel="stylesheet" href="{{asset('css/owl.transitions.css')}}">
        <link rel="stylesheet" href="{{asset('css/style.css')}}">
        <link rel="stylesheet" href="{{asset('css/responsive.css')}}">
        <link rel="stylesheet" href="{{asset('css/default.css')}}">

</head>
<body>
@include('shared.navbar')
@yield('content')

<script href="{{asset('js/bootsrap-material-design.js')}}" type="javascript"></script>
<script href="{{asset('js/bootsrap-material-design.js.map')}}" type="javascript"></script><script src="assets/js/modernizr-2.6.2.min.js"></script>

<script src="{{asset('js/jquery-1.10.2.min.js')}}"></script>
<script src="{{asset('js/bootstrap.min.js')}}"></script>
<script src="{{asset('js/bootstrap-select.min.js')}}"></script>
<script src="{{asset('js/bootstrap-hover-dropdown.js')}}"></script>

<script src="{{asset('js/easypiechart.min.js')}}"></script>
<script src="{{asset('js/jquery.easypiechart.min.js')}}"></script>

<script src="{{asset('js/owl.carousel.min.js')}}"></script>   
<script src="{{asset('js/wow.js')}}"></script>

<script src="{{asset('js/icheck.min.js')}}"></script>
<script src="{{asset('js/price-range.js')}}"></script>

<script src="{{asset('js/main.js')}}"></script>

</body>



</html>