
@extends('pages.master')
@section('title', 'contact')
@section('content')
    <div class="container">
    <div class="content">
    <div class="title">About Page</div>
    <div class="quote">Our Contactus page!</div>
    </div>
</div>
@endsection