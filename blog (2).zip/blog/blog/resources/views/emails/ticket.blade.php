<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="utf-8">
</head>
<body>
<h2>Learning Laravel!</h2>
<div>
You have a new ticket. The ticket id is {{ $ticket }}!
</div>
</body>
</html>