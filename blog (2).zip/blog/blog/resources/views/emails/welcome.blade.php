<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="utf-8">
</head>
<body>
<h2>Learning Laravel!</h2>
<div>
Welcome to {{ $name }} website!
</div>
</body>
</html>